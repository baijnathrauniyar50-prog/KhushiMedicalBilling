# Khushi Medical Billing — Full mobile-build project

Features included:
- Offline SQLite database
- Category → Group → Item
- Item: name, company, MRP, selling price, GST
- No Batch No. and no Expiry
- Bill number auto-increment
- Customer name/mobile
- Saved bills
- 58mm Bluetooth ESC/POS printer support
- Paired-printer selection
- Save & Print
- Android 6+ minimum

Build on a computer or Android build environment with Gradle/Android SDK. The chat environment cannot compile an installable APK itself.
