package com.khushi.medicalbilling;

import android.content.*;
import android.database.sqlite.*;
import android.database.Cursor;

public class DB extends SQLiteOpenHelper {
    public DB(Context c){super(c,"medical.db",null,1);}
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE categories(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL)");
        d.execSQL("CREATE TABLE groups_tbl(id INTEGER PRIMARY KEY AUTOINCREMENT,category_id INTEGER,name TEXT NOT NULL)");
        d.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT,group_id INTEGER,name TEXT NOT NULL,company TEXT,mrp REAL,price REAL,gst REAL)");
        d.execSQL("CREATE TABLE bills(id INTEGER PRIMARY KEY AUTOINCREMENT,bill_no INTEGER,customer TEXT,mobile TEXT,created TEXT,total REAL)");
        d.execSQL("CREATE TABLE bill_items(id INTEGER PRIMARY KEY AUTOINCREMENT,bill_id INTEGER,item_id INTEGER,name TEXT,qty REAL,price REAL,gst REAL,amount REAL)");
        d.execSQL("INSERT INTO categories(name) VALUES('Medicine')");
        d.execSQL("INSERT INTO categories(name) VALUES('Cosmetics')");
    }
    public void onUpgrade(SQLiteDatabase d,int a,int b){}
    public long addCategory(String n){ContentValues v=new ContentValues();v.put("name",n);return getWritableDatabase().insert("categories",null,v);}
    public long addGroup(long c,String n){ContentValues v=new ContentValues();v.put("category_id",c);v.put("name",n);return getWritableDatabase().insert("groups_tbl",null,v);}
    public long addItem(long g,String n,String co,double mrp,double price,double gst){
        ContentValues v=new ContentValues();v.put("group_id",g);v.put("name",n);v.put("company",co);v.put("mrp",mrp);v.put("price",price);v.put("gst",gst);
        return getWritableDatabase().insert("items",null,v);
    }
    public Cursor all(String sql,String[] args){return getReadableDatabase().rawQuery(sql,args);}
}
