package com.khushi.medicalbilling;

import android.bluetooth.*;
import java.io.*;
import java.util.*;

public class Printer {
    public static Set<BluetoothDevice> paired(BluetoothAdapter a){return a==null?Collections.emptySet():a.getBondedDevices();}
    public static void print(BluetoothDevice d,String text) throws Exception {
        BluetoothSocket s=d.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
        s.connect(); OutputStream o=s.getOutputStream();
        o.write(new byte[]{0x1B,0x40});
        o.write(text.getBytes("GB18030"));
        o.write(new byte[]{0x0A,0x0A,0x0A});
        o.write(new byte[]{0x1D,0x56,0x00});
        o.flush(); o.close(); s.close();
    }
}
