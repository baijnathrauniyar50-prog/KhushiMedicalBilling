package com.khushi.medicalbilling;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.bluetooth.*;
import android.database.Cursor;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout root; int blue=0xff1565c0;
    ArrayList<Line> cart=new ArrayList<>();
    static class Line { long id; String name; double qty,price,gst; Line(long i,String n,double q,double p,double g){id=i;name=n;qty=q;price=p;gst=g;} }

    public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); dashboard();}

    TextView tv(String s,int z){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setPadding(8,14,8,14);return t;}
    Button bt(String s,View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setOnClickListener(l);return b;}
    EditText ed(String hint){EditText e=new EditText(this);e.setHint(hint);e.setPadding(8,8,8,8);return e;}
    void base(String title){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(20,20,20,20);ScrollView sc=new ScrollView(this);sc.addView(root);setContentView(sc);TextView h=tv(title,25);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setTextColor(blue);root.addView(h);}

    void dashboard(){
        base("Khushi Medical Billing");
        root.addView(bt("🧾  Bill बनाना",v->newBill()));
        root.addView(bt("💾  Saved Bills",v->saved()));
        root.addView(bt("📂  Category / Group / Item",v->categories()));
        root.addView(bt("🖨️  58mm Printer",v->printer()));
        root.addView(bt("⚙️  Settings",v->settings()));
    }

    void newBill(){
        cart.clear(); base("New Bill");
        EditText customer=ed("Customer Name (optional)"), mobile=ed("Mobile Number (optional)");
        root.addView(customer);root.addView(mobile);
        root.addView(bt("+ Add Item",v->pickItem()));
        TextView total=tv("Total: ₹0.00",20);root.addView(total);
        root.addView(bt("💾 Save Bill",v->{long id=saveBill(customer.getText().toString(),mobile.getText().toString());toast("Bill saved #"+id);}));
        root.addView(bt("🖨️ Save & Print",v->{long id=saveBill(customer.getText().toString(),mobile.getText().toString());printLatest(id);}));
        root.addView(bt("← Back",v->dashboard()));
    }

    void pickItem(){
        Cursor c=db.all("SELECT i.id,i.name,i.price,i.gst FROM items i ORDER BY i.name",null);
        ArrayList<String> names=new ArrayList<>(); final ArrayList<Long> ids=new ArrayList<>();
        while(c.moveToNext()){ids.add(c.getLong(0));names.add(c.getString(1)+"  ₹"+c.getDouble(2));} c.close();
        if(names.size()==0){toast("पहले Category → Group → Item में item बनाइए");return;}
        new AlertDialog.Builder(this).setTitle("Select Item").setItems(names.toArray(new String[0]),(d,w)->{
            Cursor x=db.all("SELECT name,price,gst FROM items WHERE id=?",new String[]{""+ids.get(w)});
            if(x.moveToFirst()) cart.add(new Line(ids.get(w),x.getString(0),1,x.getDouble(1),x.getDouble(2))); x.close();
            toast("Item added");
        }).show();
    }

    long saveBill(String customer,String mobile){
        double total=0;for(Line l:cart)total+=l.qty*l.price*(1+l.gst/100);
        android.database.sqlite.SQLiteDatabase d=db.getWritableDatabase();
        Cursor c=d.rawQuery("SELECT COALESCE(MAX(bill_no),0)+1 FROM bills",null);c.moveToFirst();long no=c.getLong(0);c.close();
        ContentValues v=new ContentValues();v.put("bill_no",no);v.put("customer",customer);v.put("mobile",mobile);v.put("created",new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date()));v.put("total",total);
        long id=d.insert("bills",null,v);
        for(Line l:cart){ContentValues q=new ContentValues();q.put("bill_id",id);q.put("item_id",l.id);q.put("name",l.name);q.put("qty",l.qty);q.put("price",l.price);q.put("gst",l.gst);q.put("amount",l.qty*l.price*(1+l.gst/100));d.insert("bill_items",null,q);}
        return no;
    }

    void saved(){
        base("Saved Bills");Cursor c=db.all("SELECT bill_no,customer,created,total FROM bills ORDER BY id DESC",null);
        while(c.moveToNext())root.addView(tv("#"+c.getLong(0)+"  "+c.getString(1)+"\n"+c.getString(2)+"   ₹"+String.format(Locale.getDefault(),"%.2f",c.getDouble(3)),17));
        c.close();root.addView(bt("← Back",v->dashboard()));
    }

    void categories(){
        base("Categories");
        root.addView(bt("+ Add Category",v->addCategory()));
        root.addView(bt("+ Add Group",v->addGroup()));
        root.addView(bt("+ Add Item",v->addItem()));
        root.addView(tv("Structure: Category → Group → Item\nItem fields: Name, Company, MRP, Selling Price, GST, Quantity\nBatch No. और Expiry नहीं हैं.",16));
        root.addView(bt("← Back",v->dashboard()));
    }

    void addCategory(){EditText e=ed("Category name");new AlertDialog.Builder(this).setTitle("Add Category").setView(e).setPositiveButton("Save",(d,w)->{db.addCategory(e.getText().toString());toast("Saved");}).show();}
    void addGroup(){
        EditText e=ed("Group name");Cursor c=db.all("SELECT id,name FROM categories ORDER BY name",null);ArrayList<String> n=new ArrayList<>();ArrayList<Long> id=new ArrayList<>();while(c.moveToNext()){id.add(c.getLong(0));n.add(c.getString(1));}c.close();
        new AlertDialog.Builder(this).setTitle("Choose Category").setItems(n.toArray(new String[0]),(d,w)->new AlertDialog.Builder(this).setTitle("Add Group").setView(e).setPositiveButton("Save",(x,y)->{db.addGroup(id.get(w),e.getText().toString());toast("Saved");}).show()).show();
    }
    void addItem(){
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);
        EditText n=ed("Item / Medicine name"),co=ed("Company"),mr=ed("MRP"),pr=ed("Selling Price"),gst=ed("GST %");p.addView(n);p.addView(co);p.addView(mr);p.addView(pr);p.addView(gst);
        Cursor c=db.all("SELECT id,name FROM groups_tbl ORDER BY name",null);ArrayList<String> ns=new ArrayList<>();ArrayList<Long> ids=new ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));ns.add(c.getString(1));}c.close();
        new AlertDialog.Builder(this).setTitle("Select Group").setItems(ns.toArray(new String[0]),(d,w)->new AlertDialog.Builder(this).setTitle("Add Item").setView(p).setPositiveButton("Save",(x,y)->{try{db.addItem(ids.get(w),n.getText().toString(),co.getText().toString(),Double.parseDouble(mr.getText().toString()),Double.parseDouble(pr.getText().toString()),Double.parseDouble(gst.getText().toString()));toast("Item saved");}catch(Exception z){toast("Details check करें");}}).show()).show();
    }

    void printer(){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission("android.permission.BLUETOOTH_CONNECT")!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.BLUETOOTH_CONNECT","android.permission.BLUETOOTH_SCAN"},20);
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null){toast("Bluetooth not available");return;}
        Set<BluetoothDevice> set=Printer.paired(a);ArrayList<BluetoothDevice> dev=new ArrayList<>(set);String[] n=new String[dev.size()];for(int i=0;i<dev.size();i++)n[i]=dev.get(i).getName()+"\n"+dev.get(i).getAddress();
        new AlertDialog.Builder(this).setTitle("Paired 58mm Printers").setItems(n,(d,w)->getPreferences(0).edit().putString("printer",dev.get(w).getAddress()).apply()).setNegativeButton("Close",null).show();
    }

    void printLatest(long billNo){
        String addr=getPreferences(0).getString("printer",null);if(addr==null){toast("पहले 58mm Printer में paired printer select करें");return;}
        try{
            BluetoothDevice d=BluetoothAdapter.getDefaultAdapter().getRemoteDevice(addr);
            Cursor b=db.all("SELECT bill_no,customer,created,total FROM bills WHERE bill_no=?",new String[]{""+billNo});
            StringBuilder s=new StringBuilder();if(b.moveToFirst()){s.append("       KHUSHI MEDICAL\n");s.append("--------------------------------\n");s.append("Bill: ").append(b.getLong(0)).append("  ").append(b.getString(2)).append("\n");s.append("Customer: ").append(b.getString(1)).append("\n--------------------------------\n");}b.close();
            Cursor it=db.all("SELECT name,qty,price,amount FROM bill_items WHERE bill_id=(SELECT id FROM bills WHERE bill_no=?)",new String[]{""+billNo});
            while(it.moveToNext())s.append(String.format(Locale.getDefault(),"%-18s %2.0f %7.2f\n",it.getString(0),it.getDouble(1),it.getDouble(3)));it.close();
            s.append("--------------------------------\n");
            Cursor t=db.all("SELECT total FROM bills WHERE bill_no=?",new String[]{""+billNo});if(t.moveToFirst())s.append(String.format(Locale.getDefault(),"TOTAL: ₹%.2f\n",t.getDouble(0)));t.close();s.append("--------------------------------\n        Thank You\n");
            Printer.print(d,s.toString());toast("Printed");
        }catch(Exception e){toast("Printer connection failed: "+e.getMessage());}
    }

    void settings(){base("Settings");root.addView(tv("Shop name, address, mobile और GST settings को अगले build में editable रखा जा सकता है.\n\nCurrent version: offline medical billing + saved bills + 58mm Bluetooth printing.",16));root.addView(bt("← Back",v->dashboard()));}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
